#Open eQuarter
An QGIS-plugin, which enables users to define an area of interest, clip the areas extent from a wms and to analyse that piece in one go.