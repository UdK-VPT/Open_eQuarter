def ext_path(): return os.path.dirname(os.path.realpath(__file__))
def ext_path_list = os.listdir(os.path.dirname(os.path.realpath(__file__)))
  
#class OEQ_Extension:

#  return None
  