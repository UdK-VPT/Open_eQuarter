mw = iface.mainWindow()
mw.findChild(QTreeWidget, 'mLayerTreeWidget')
<PyQt4.QtGui.QTreeWidget object at 0x000000000FD61AE8>

root = QgsProject.instance().layerTreeRoot()
<qgis._core.QgsLayerTreeGroup object at 0x000000000FD616A8>